package com.holmes.holmesbrewery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolmesBreweryApplicationTests {

	@Test
	void contextLoads() {
	}

}
