package com.holmes.holmesbrewery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolmesBreweryApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolmesBreweryApplication.class, args);
	}

}
